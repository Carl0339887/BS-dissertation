# coding = utf-8
import numpy as np
import random as ran
import pickle

L = 10  # 2D square lattice L by L
u = [[0 for j in range(L)] for i in range(L)]  # Configuration array
J = 1.0  # Exchange coefficient


def config_init(cmd):
    """
    Initialize spin lattice
    """
    if cmd == 'High temperature':
        for i in range(L):
            for j in range(L):
                if ran.random() < 0.5:
                    u[i][j] = -1
                else:
                    u[i][j] = +1
    elif cmd == 'Low temperature':
        for i in range(L):
            for j in range(L):
                if ran.random() < 0.5:
                    u[i][j] = +1
                else:
                    u[i][j] = +1
    else:
        print 'Please give a command to initialize.'


def config_print():
    """
    Print out configuration
    """
    for i in range(L):
        for j in range(L):
            print '%2d '%u[i][j],
        print


def config_energy(array):
    """
    :return: Energy of this configuration
    """
    total_energy = 0
    for i in range(L):
        for j in range(L):
            right = np.mod((j + 1), L)
            down = np.mod((i + 1), L)
            total_energy += -J * array[i][j] * (array[i][right] + array[down][j])
    return total_energy / L / L  # Energy per lattice



def neighbor_loc(seq_num, neighbor_idx):
    """
    :param seq_num: defines original position
    :param neighbor_idx: 0 = up, 1 = right, 2 = down, 3 = left
    :return: seq_num of neighbor
    """
    i, j = sequence_coordinate(seq_num)
    if neighbor_idx == 0:
        up = i - 1
        if up < 0: up = L - 1
        return coordinate_sequence(up, j)
    if neighbor_idx == 1:
        right = j + 1
        if right >= L: right = 0
        return coordinate_sequence(i, right)
    if neighbor_idx == 2:
        down = i + 1
        if down >= L: down = 0
        return coordinate_sequence(down, j)
    if neighbor_idx == 3:
        left = j - 1
        if left < 0: left = L - 1
        return coordinate_sequence(i, left)


def sequence_coordinate(seq_num):
    """
    :param: seq_num <= L*L - 1
    :return: coordinate tuple
    """
    col = seq_num % L
    row = (seq_num - col) // L
    return row, col


def coordinate_sequence(x, y):
    return x * L + y


#######################  Cluster  #############################
def cluster_update(Temperature):
    """
    This routine applies Wolff cluster update to achieve a configuration (u) trans.
    """
    ##  Start point  ##
    start = ran.randint(0, L * L - 1)
    cluster = []  # Store sequence number of cluster sites
    pocket = []
    cluster.append(start)
    pocket.append(start)

    ##  Cluster grow  ##
    beta = 1 / k_B / Temperature
    # print 'beta =', beta
    while len(pocket) > 0:
        k = ran.choice(pocket)
        for neighbor in range(4):
            l = neighbor_loc(seq_num=k, neighbor_idx=neighbor)
            x_l, y_l = sequence_coordinate(l)
            x_k, y_k = sequence_coordinate(k)
            if (l not in cluster) and (u[x_l][y_l] == u[x_k][y_k]):
                if ran.random() < (1 - np.exp(-2*beta*J)):
                    pocket.append(l)
                    cluster.append(l)
        pocket.remove(k)

    ##  Cluster flip  ##
    for k in cluster:
        x, y = sequence_coordinate(k)
        u[x][y] = -u[x][y]


################  Measurement  ###################

def measure(Temperature):
    ##  Start measuring at low temperature  ##
    energy = []
    for sample in range(100):  # Sample 100 times
        cluster_update(Temperature)
        energy.append(float(config_energy(u)))

    av, var = av_and_var(energy)
    # sd = np.sqrt(var)
    return av, var

def av_and_var(input_array):
    """
    :param input_array: In put a list
    :return: Average and Variance as a tuple
    """
    array = np.array(input_array)
    average = float(array.sum()) / len(array)
    array2 = array * array
    array2sum = float(array2.sum())
    variance = array2sum / len(array) - average ** 2
    return average, variance



################## MAIN #######################
k_B = 1.0  # Boltzmann constant
T_start = 30.0  # Absolute temperature
T_finish = 1.0  # From start temperature down to finish temperature
dT = 0.1  # Temperature step

group = 20  # Number of measurement carried out under each temperature
interval = 1000  # Interval between groups of measurements



def main():
    f_energy = open('energy.dat', 'w+')
    config_init('Low temperature')

    for iT in range(int((T_start - T_finish)//dT) + 1):
        T = T_start - iT * dT  # Annealing from T_start
        print T
        ##  Warm up after temperature changes ##
        warmup = 5000  # Need to check -- autocorrelation time
        if T <= 20.0:
            warmup = 9999

        for step in range(warmup):
            cluster_update(T)

        ##  Measurement starts at low temperature  ##
        if T <= 15.0:
            energy_tmp = []
            for group_measure in range(group):
                for i in range(interval):
                    cluster_update(T)
                energy_av, energy_var = measure(T)
                energy_tmp.append(energy_av)
            result_mean, result_var = av_and_var(energy_tmp)
            f_energy.write('T = %6.3f, E = %7.4f, Var = %7.4f\n' % (T, result_mean, result_var))

    f_energy.close()


# main()
#config_init('High temperature')
#print measure(10.0)

#################  TEST area  ######################

def test():
    config_init('High temperature')
    config_print()
  #  print 'Init', config_energy(u)
 #   cluster_update(2)
   # print cluster
  #  config_print()
  #  print 'Fin', config_energy(u)


# test()
def test2():
    config_init('High temperature')
    for step in range(1000):
        cluster_update(100.0)

    energy = []
    for sample in range(100):
        energy.append(config_energy(u))
        cluster_update(Temperature=100.0)

    av,var = av_and_var(energy)
    print av,np.sqrt(var)
  #  print energy




