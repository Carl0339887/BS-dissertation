# coding = utf-8
import string
import matplotlib.pyplot as plt
f = open('energy.dat','r')
T = []
E = []
while True:
    txt = f.readline()
    print txt
    if txt == '':
        break
    temperature = txt[4:9]
    energy = txt [16:23]
    T.append(float(temperature))
    E.append(float(energy))


f.close()

plt.scatter(T,E,s=5)
plt.savefig('E_T.png')
plt.show()
