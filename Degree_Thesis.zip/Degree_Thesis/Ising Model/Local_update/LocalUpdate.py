#  Coding = UTF-8
import numpy as np
import random as ran


L = 10  # 2D square lattice L by L
u = [[0 for j in range(L)] for i in range(L)]  # Configuration array
J = 1.0  # Exchange coefficient
k_B = 1.0 # Boltzmann constant


def config_init(cmd):
    """
    Initialize spin lattice
    """
    if cmd == 'High temperature':
        for i in range(L):
            for j in range(L):
                if ran.random() < 0.5:
                    u[i][j] = -1
                else:
                    u[i][j] = +1
    elif cmd == 'Low temperature':
        for i in range(L):
            for j in range(L):
                if ran.random() < 0.5:
                    u[i][j] = +1
                else:
                    u[i][j] = +1
    else:
        print 'Please give a command to initialize.'


def config_print():
    """
    Print out configuration
    """
    for i in range(L):
        for j in range(L):
            print '%2d ' % u[i][j],
        print


def config_energy():
    """
    :return: Energy of this configuration
    """
    total_energy = 0
    for i in range(L):
        for j in range(L):
            right = np.mod((j + 1), L)
            down = np.mod((i + 1), L)
            total_energy += -J * u[i][j] * (u[i][right] + u[down][j])
    return total_energy / L / L  # Energy per lattice


def nn_energy(array, i, j):
    """
    input = array name and coordinates
    :return: nearest neighbor energy
    """
    tmp = 0.0

    left = j - 1
    if left < 0:
        left = L - 1
    tmp += -J * array[i][left] * array[i][j]

    right = j + 1
    if right >= L:
        right = 0
    tmp += -J * array[i][right] * array[i][j]

    up = i - 1
    if up < 0:
        up = L - 1
    tmp += -J * array[up][j] * array[i][j]

    down = i + 1
    if down >= L:
        down = 0
    tmp += -J * array[down][j] * array[i][j]
    return tmp


def local_update(Temperature):
    #  Sweep over each vertex  #
    for i in range(L):
        for j in range(L):
            flip_energy = -2 * nn_energy(u,i,j)
            if ran.random() < np.exp(-flip_energy / k_B / Temperature):
                u[i][j] = -u[i][j]


def av_and_var(input_array):
    """
    :param input_array: In put a list
    :return: Average and Variance as a tuple
    """
    array = np.array(input_array)
    average = float(array.sum()) / len(array)
    array2 = array * array
    array2sum = float(array2.sum())
    variance = array2sum / len(array) - average ** 2
    return average, variance


def measure(Temperature):
    ##  Start measuring at low temperature  ##
    energy = []
    for sample in range(100):  # Sample 100 times
        local_update(Temperature)
        energy.append(float(config_energy()))

    av, var = av_and_var(energy)
    # sd = np.sqrt(var)
    return av, var


def main():
    T = 30.0
    dT = 0.1
    warmup = 5000
    interval = 1000
    group = 20

    config_init('High temperature')
    f_energy = open('energy.dat', 'w+')
    while T >= 0.9:
        T -= dT
        print T
        for ir in range(warmup):
            local_update(T)
        if T <= 15.0:
            energy_tmp = []
            for group_measure in range(group):
                for ir in range(interval):
                    local_update(T)
                energy_av, energy_var = measure(T)
                energy_tmp.append(energy_av)

            result_mean, result_var = av_and_var(energy_tmp)
            f_energy.write('T = %6.3f, E = %7.4f, Var = %7.4f\n' % (T, result_mean, result_var))

    f_energy.close()
    pass

main()

