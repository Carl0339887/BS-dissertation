# coding = utf-8

import matplotlib.pyplot as plt
f = open('energy.dat', 'r')
T = []
E = []
c = []
dT = 0.1
while True:
    txt = f.readline()
    # print txt
    if txt == '':
        break
    temperature = txt[4:9]
    energy = txt[16:23]
    T.append(float(temperature))
    E.append(float(energy))


f.close()
f_out = open('ising_E.txt', 'w+')
for i in range(len(E)):
    f_out.write('%7.4f\n'%E[i])
f_out.close()


for i in range(len(E)-1):
    c.append(-(E[i+1]-E[i])/dT)

del T[-1]
plt.scatter(T, c, s=5)
# plt.savefig('C_T.png')
plt.show()


