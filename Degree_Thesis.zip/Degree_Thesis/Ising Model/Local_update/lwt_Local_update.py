# Monte Carlo algorithm for the Ising model on a L x L square lattice
# Written by whuCanon at 2016/04/11

import random
import math
import matplotlib
matplotlib.use('TKAgg')
from matplotlib import pyplot

from matplotlib import animation


L = 10
T = 2.25
H = 0.

s = []
sweep = 10


def calEflip(s, row, col):
    spin_up_row    = (row+1) % L
    spin_down_row  = (row-1) % L
    spin_right_col = (col+1) % L
    spin_left_col  = (col-1) % L
    e_betw_up      = -s[row][col] * s[spin_up_row][col]
    e_betw_down    = -s[row][col] * s[spin_down_row][col]
    e_betw_right   = -s[row][col] * s[row][spin_right_col]
    e_betw_left    = -s[row][col] * s[row][spin_left_col]
    return -2 * (e_betw_up + e_betw_down + e_betw_left + e_betw_right)


def getMagn(s):
    m = 0.
    for i in range(L):
        for j in range(L):
            m += s[i][j]
    m /= L * L
    return m


def display():
    x, y = [], []
    fig = pyplot.figure(figsize=(20,6))
    xmin, xmax = 0, 3000
    ymin, ymax = -1, 1
    dy = (ymax - ymin) * 0.2
    ax = pyplot.axes(xlim=(xmin, xmax), ylim=(ymin - dy, ymax + dy))
    line, = ax.plot([], [])

    # name the axis
    pyplot.xlabel(r'$time$', fontsize=16)
    pyplot.ylabel(r'$Magnetization$', fontsize=16)

    # draw animation
    def initAnimation():
        line.set_data([], [])
        return line,

    def animate(i):
        global s
        for row in range(L):
            for col in range(L):
                eflip = calEflip(s, row, col)
                if eflip <= 0:
                    s[row][col] = -s[row][col]
                elif random.random() <= math.exp(-eflip / T):
                    s[row][col] = -s[row][col]
                # else:
                #     continue
        x.append(i)
        y.append(getMagn(s))
        line.set_data(x, y)
        return line,

    anim = animation.FuncAnimation(fig, animate, init_func=initAnimation, interval=20, blit=True)
    pyplot.show()


# initial all spins
for i in range(L):
    tmp = []
    for j in range(L):
        tmp.append(1.)
    s.append(tmp)

display()