# coding = utf - 8
import numpy as np
L = 2
N = L * L
s = [1 for i in range(N)]
u = [[0 for j in range(L)] for i in range(L)]

J = 1.0  # Exchange coefficient
K = 0.3 * J # Four-spin interaction coefficient
k_B = 1.0 # Boltzmann constant


def config_energy():
    """
    Total = Ising + 4-spin
    :return: Ising and Total energy per spin as a tuple
    """
    ising_energy = 0
    fourspin_energy = 0
    for i in range(L):
        for j in range(L):
            right = np.mod((j + 1), L)
            down = np.mod((i + 1), L)
            # Ising:
            ising_energy += -J * u[i][j] * (u[i][right] + u[down][j])
            # 4-spin:
            fourspin_energy += -K * u[i][j] * u[i][right] * u[down][j] * u[right][down]

    total_energy = ising_energy + fourspin_energy
    return ising_energy / L / L, total_energy / L / L  # Energy per spin

def getEnergy():
    u[0][0] = s[0]
    u[0][1] = s[1]
    u[1][0] = s[2]
    u[1][1] = s[3]
    print config_energy()

def re(n):
    if n == 0:
        # print s
        getEnergy()
        s[n] = -s[n]
        # print s
        getEnergy()
    else:
        re(n-1)
        s[n] = -s[n]
        re(n-1)


re(N-1)


