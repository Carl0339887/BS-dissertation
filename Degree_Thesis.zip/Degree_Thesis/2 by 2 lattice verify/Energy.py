# coding = utf - 8

L = 2
u = [[0 for j in range(L)] for i in range(L)]


def config_print():
    """
    Print out configuration
    """
    for i in range(L):
        for j in range(L):
            print '%2d '%u[i][j],
        print

def config_energy():
    """
    Total = Ising + 4-spin
    :return: Ising and Total energy per spin as a tuple
    """
    ising_energy = 0
    fourspin_energy = 0
    for i in range(L):
        for j in range(L):
            right = np.mod((j + 1), L)
            down = np.mod((i + 1), L)
            # Ising:
            ising_energy += -J * u[i][j] * (u[i][right] + u[down][j])
            # 4-spin:
            fourspin_energy += -K * u[i][j] * u[i][right] * u[down][j] * u[right][down]

    total_energy = ising_energy + fourspin_energy
    return ising_energy / L / L, total_energy / L / L  # Energy per spin


config_print()

