# coding = utf - 8
import time
import numpy as np
t0 = time.clock()
t1 = time.time()

time.sleep(2.5)
print time.clock() - t0

print time.time() - t1


def av(input_array):
    """
    :param input_array: In put a list
    :return: Average value
    """
    array = np.array(input_array)
    average = float(array.sum()) / len(array)

    return average

print av([1, 2, 3, 4, 5])