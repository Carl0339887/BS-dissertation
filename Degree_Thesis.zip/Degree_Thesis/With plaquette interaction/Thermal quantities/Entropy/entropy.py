# coding = utf - 8
"""
First several points are original, then fitted curve
"""
import numpy as np
import pickle
import matplotlib.pyplot as plt

E = []
T = []
S = []

S_inf = np.log(2)  # def S(21.0) = S(inf)
dT = 0.1


f_p = open('E-T.pkl','r')
T_read = pickle.load(f_p)
E_read = pickle.load(f_p)
f_p.close()

for i in range(len(T_read)):
    T.append(T_read[i])
    E.append(E_read[i])

#print E
#print T[-1], T[0]
E.reverse()
T.reverse()
#print E
#print T[-1], T[0], type(E[1])


for i in range(206):

    I = 0
    for j in range(i+1):

        I += (E[j] / T[j] / T[j] + E[j] / T[j+1] / T[j+1])*0.5* dT

        pass
    S.append(S_inf - I + E[i] / T[i])
    # print T[i],S[-1]
    pass

S.reverse()
T.reverse()
S.append(S_inf)

font = {'family': 'serif',
        'color': 'darkred',
        'weight': 'normal',
        'size': 16}

plt.title('S-T relation', fontdict=font)
plt.xlabel('Temperature', fontdict=font)
plt.ylabel('Entropy', fontdict=font)


#print S.index(min(S))
#print T
plt.plot(T[12:],S[12:],'-')
plt.scatter(T[12:],S[12:],s=4)
plt.xlim(0,10)
plt.ylim(0,0.7)
plt.savefig('entropy.png')
plt.show()

def out():
    f_p = open('S-T.pkl','w+')
    for i in range(len(T)):
        pickle.dump(T,f_p)
        pickle.dump(S,f_p)
    f_p.close()


# out()



