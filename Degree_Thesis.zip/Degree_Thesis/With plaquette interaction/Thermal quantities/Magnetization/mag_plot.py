# coding = utf - 8

import matplotlib.pyplot as plt
M = []
T = []

f = open('energy&mag.dat','r')
while True:
    txt = f.readline()
    # print txt
    if txt == '':
        break
    temperature = txt[4:9]
    magnetization = txt[47:53]

    T.append(float(temperature))
    M.append(float(magnetization))

f.close()



font = {'family': 'serif',
        'color': 'darkred',
        'weight': 'normal',
        'size': 16}


plt.xlim(1,10.0)
plt.ylim(0,1.1)
plt.title('M-T relation', fontdict=font)
plt.xlabel('Temperature', fontdict=font)
plt.ylabel('Magnetization (per spin)', fontdict=font)



plt.plot(T,M,'-')

plt.scatter(T,M,s=4)
plt.savefig('Mag.png')
plt.show()











