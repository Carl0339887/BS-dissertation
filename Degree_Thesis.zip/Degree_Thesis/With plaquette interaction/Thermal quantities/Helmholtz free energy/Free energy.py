# coding = utf - 8
import matplotlib.pyplot as plt
import pickle

T = []

S = []
F = []
f_p = open('S-T.pkl','r')
T_read = pickle.load(f_p)
S_read = pickle.load(f_p)
f_p.close()

f_p = open('E-T.pkl','r')
T_read = pickle.load(f_p)
E_read = pickle.load(f_p)
f_p.close()


print T_read[0],E_read
for i in range(len(T_read)):
    T.append(T_read[i])
    S.append(S_read[i])
    F.append(E_read[i]-T[i] * S[i])



font = {'family': 'serif',
        'color': 'darkred',
        'weight': 'normal',
        'size': 16}


plt.xlim(1.0,10.0)
plt.ylim(-8,-2)
plt.title('F-T relation', fontdict=font)
plt.xlabel('Temperature', fontdict=font)
plt.ylabel('Free Energy', fontdict=font)


plt.plot(T[11:],F[11:])

plt.scatter(T[11:],F[11:],s=4)
plt.savefig('F-T.png')
plt.show()











