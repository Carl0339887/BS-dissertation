# coding = utf-8
import numpy as np
import matplotlib.pyplot as plt
import pickle


E = []
T = []
dT = 0.1
dE = []


f_p = open('E-T.pkl','r')
T_read = pickle.load(f_p)
E_read = pickle.load(f_p)
f_p.close()

for i in range(len(T_read)):
    T.append(T_read[i])
    E.append(E_read[i])


for i in range(len(E)-1):
    dE.append((E[i+1]-E[i])/dT)

del T[-1]



font = {'family': 'serif',
        'color': 'darkred',
        'weight': 'normal',
        'size': 16}

#plt.plot(x1,y,'--',label='T=2.50')
#plt.legend(loc = 'lower right')

plt.annotate('Maximum', xy=(2.50, max(dE)), xycoords='data',
                xytext=(20, -30), textcoords='offset points',
                arrowprops=dict(arrowstyle="->")
                )
plt.plot([2.49],[max(dE)],"bo")



plt.plot(T,dE)
plt.xlim(0.0,10.0)
plt.ylim(min(dE)-0.05,max(dE)+0.05)
plt.title('c-T relation', fontdict=font)
plt.xlabel('Temperature', fontdict=font)
plt.ylabel('Specific Heat', fontdict=font)
plt.savefig('C-T.png')


plt.show()

















