# coding = utf - 8
# Fitted E-T relation using Matlab
import numpy as np
import matplotlib.pyplot as plt
import pickle

def f(x,a,b,c):
    return a*np.exp(-((x-b)/c)**2)

x = np.linspace(1.1,21.1,200,endpoint=True)

a1 = -0.7501
b1 = 1.949
c1 = 0.9122

a2 = -1.778 * 10 ** 13
b2 = -106
c2 = 19.53

a3 = 0.1243
b3 = 2.799
c3 = 0.4071

a4 = -5.944
b4 = -72.25
c4 = 45.19

y = f(x,a1,b1,c1)+f(x,a2,b2,c2)+f(x,a3,b3,c3)+f(x,a4,b4,c4)

Dy = []
for i in range(len(y)-1):
    Dy.append((y[i+1]-y[i]) / 0.2 -2)





############################################



f = open('energy.txt','r')
T_read = []
E_read = []
dT = 0.1
while True:
    txt = f.readline()
    # print txt
    if txt == '':
        break
    temperature = txt[4:9]
    energy = txt[16:23]
    T_read.append(float(temperature))
    E_read.append(float(energy))

f.close()
E_read.reverse()


############################################


E = []
T = []
# Personal added
for i in range(4,11):
    T.append(i*0.1)
    E.append(-2.3)

# First 7 points original
for i in range(7):
    T.append((i+11)*0.1)
    E.append(E_read[i])

# Fitted data

for i in range(200-7):
    T.append((i+18)*0.1)
    E.append(y[i+7])

#plt.plot(T,E,'--')

#plt.xlim(0,10)
#plt.ylim(-2.31,-2)
#plt.plot(x[:-1],Dy,'-')




def file_test():
    f_p = open('E-T.pkl','w+')
    for i in range(len(T)):
        pickle.dump(T,f_p)
        pickle.dump(E,f_p)
    f_p.close()

    f_p = open('E-T.pkl','r')
    tmptr = pickle.load(f_p)
    engy = pickle.load(f_p)
    #print tmptr
    #print len(tmptr), tmptr[-1]
    #print engy
    f_p.close()

file_test()

x0 = []
x1 = []
y = []
for i in range(55):
    x0.append(2.26918)
    x1.append(2.49)
    y.append(i*0.05 -2.5)


font = {'family': 'serif',
        'color': 'darkred',
        'weight': 'normal',
        'size': 16}


plt.xlim(0.0,10.0)
plt.ylim(-2.5,0)
plt.title('E-T relation', fontdict=font)
plt.xlabel('Temperature', fontdict=font)
plt.ylabel('Energy', fontdict=font)


plt.plot(x0,y,'--',label='Ising $T_c$')
plt.plot(x1,y,'.',label = '$T_c$')
plt.plot(T,E,'-')
plt.legend(loc='lower right')
#plt.ylim(-2.31,-2)
#plt.plot(x[:-1],Dy,'-')


plt.savefig('E-T(Tc).png')
plt.show()



