#  Coding = UTF-8
import pickle
import numpy as np
from scipy.optimize import curve_fit

J = 1.0

total_energy = []
ising_spin = []  # Def: Ising = nearest neighbor energy / -J
f = open('sample.pkl','r')

for i in range(41 * 1000):
    total_energy.append(pickle.load(f))
    ising_spin.append(pickle.load(f) / -J)

K = pickle.load(f)
f.close()



def func(x, E_0, J_1):
    return E_0 - J_1 * x

xdata = np.array(ising_spin)
ydata = np.array(total_energy)
popt, pcov = curve_fit(func, xdata, ydata)
y_fit = [func(i, popt[0],popt[1]) for i in xdata]

result = open('fitting.txt','a')
result.write('K = %3.1fJ, E_0 = %7.5f, J_1 = %7.5f\n' % (K, popt[0], popt[1]))
result.close()


