# coding = utf-8

import matplotlib.pyplot as plt
import numpy as np
f = open('energy.txt','r')
T = []
E = []
while True:
    txt = f.readline()
    # print txt
    if txt == '':
        break
    temperature = txt[4:9]
    energy = txt[16:23]
    T.append(float(temperature))
    E.append(float(energy))

f.close()

x0 = []
y = []
for i in range(55):
    x0.append(2.26918)
    y.append(i*0.05 -2.5)

x1 = []
for i in range(55):
    x1.append(2.49)
def fit():

    def f(x, a, b, c):
        return a * np.exp(-((x - b) / c) ** 2)

    x = np.linspace(1.0, 10.0, 100, endpoint=True)

    a1 = -0.7501
    b1 = 1.949
    c1 = 0.9122

    a2 = -1.778 * 10 ** 13
    b2 = -106
    c2 = 19.53

    a3 = 0.1243
    b3 = 2.799
    c3 = 0.4071

    a4 = -5.944
    b4 = -72.25
    c4 = 45.19

    y = f(x, a1, b1, c1) + f(x, a2, b2, c2) + f(x, a3, b3, c3) + f(x, a4, b4, c4)

    plt.plot(x[8:], y[8:], '-', label = 'Fitted')

fit()

plt.scatter(T, E, s=5,label='Raw')



font = {'family': 'serif',
        'color': 'darkred',
        'weight': 'normal',
        'size': 16}

plt.xlim(0.0,10.0)
plt.ylim(-2.5,0)
plt.title('E-T relation', fontdict=font)
plt.xlabel('Temperature', fontdict=font)
plt.ylabel('Energy', fontdict=font)
plt.savefig('E-T_fitted.png')


plt.plot(x0,y,'--')
plt.plot(x1,y,'-')
plt.legend(loc='lower right')
# plt.savefig('E_T(Tc).png')
plt.show()


