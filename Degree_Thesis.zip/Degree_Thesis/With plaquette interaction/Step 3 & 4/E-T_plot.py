# coding = utf -8
import numpy as np
import matplotlib.pyplot as plt


f = open('energy.txt','r')
T = []
E = []
while True:
    txt = f.readline()
    # print txt
    if txt == '':
        break
    temperature = txt[4:9]
    energy = txt[16:23]
    T.append(float(temperature))
    E.append(float(energy))

f.close()

x1 = []
for i in range(55):
    x1.append(2.54)
y = []
for i in range(55):
    y.append(i*0.05 -2.5)



font = {'family': 'serif',
        'color': 'darkred',
        'weight': 'normal',
        'size': 16}

plt.plot(x1,y,'--')
plt.scatter(T,E,s=4)

plt.xlim(0.0,max(T)+0.5)
plt.ylim(-2.5,0)
plt.title('E-T relation', fontdict=font)
plt.xlabel('Temperature', fontdict=font)
plt.ylabel('Energy', fontdict=font)
plt.savefig('E-T_raw.png')
plt.show()




