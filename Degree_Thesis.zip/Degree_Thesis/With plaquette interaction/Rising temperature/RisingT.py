# coding = utf-8

"""
Perform simulation using effective Hamiltonian with acceptance rate,
where information from original Hamiltonian embedded.
"""
import numpy as np
import random as ran
import time

L = 10  # 2D square lattice L by L
u = [[0 for j in range(L)] for i in range(L)]  # Configuration array
u_propose = [[1 for j in range(L)] for i in range(L)]  # Temporary array

J_1 = 1.06458  # Effective coefficient
E_0 = 0.02055
J = 1.0  # Original coefficient
K = 0.3 * J

def config_init(cmd):
    """
    Initialize spin lattice
    """
    if cmd == 'High temperature':
        for i in range(L):
            for j in range(L):
                if ran.random() < 0.5:
                    u[i][j] = -1
                else:
                    u[i][j] = +1
    elif cmd == 'Low temperature':
        for i in range(L):
            for j in range(L):
                if ran.random() < 0.5:
                    u[i][j] = +1
                else:
                    u[i][j] = +1
    else:
        print 'Please give a command to initialize.'


def config_print():
    """
    Print out configuration
    """
    for i in range(L):
        for j in range(L):
            print '%2d '%u[i][j],
        print


def config_energy_original(array):
    """
    Total = Ising + 4-spin
    :return: Ising and Total energy per spin as a tuple
    """
    ising_energy = 0
    fourspin_energy = 0
    for i in range(L):
        for j in range(L):
            right = np.mod((j + 1), L)
            down = np.mod((i + 1), L)
            # Ising:
            ising_energy += -J * array[i][j] * (array[i][right] + array[down][j])
            # 4-spin:
            fourspin_energy += -K * array[i][j] * array[i][right] * array[down][j] * array[down][right]

    total_energy = ising_energy + fourspin_energy
    return float(ising_energy) / L / L, float(total_energy) / L / L  # Energy per spin

def config_energy_effective(array):
    """
    :return: Effective energy of this configuration.
    """
    total_energy = 0
    for i in range(L):
        for j in range(L):
            right = np.mod((j + 1), L)
            down = np.mod((i + 1), L)
            total_energy += -J_1 * array[i][j] * (array[i][right] + array[down][j])

    return (total_energy + E_0) / L / L  # Energy per lattice

def config_magnetization(array):
    mag = 0
    for i in range(L):
        for j in range(L):
            mag += array[i][j]

    return float(abs(mag)) / L / L

def neighbor_loc(seq_num, neighbor_idx):
    """
    :param seq_num: defines original position
    :param neighbor_idx: 0 = up, 1 = right, 2 = down, 3 = left
    :return: seq_num of neighbor
    """
    i, j = sequence_coordinate(seq_num)
    if neighbor_idx == 0:
        up = i - 1
        if up < 0: up = L - 1
        return coordinate_sequence(up, j)
    if neighbor_idx == 1:
        right = j + 1
        if right >= L: right = 0
        return coordinate_sequence(i, right)
    if neighbor_idx == 2:
        down = i + 1
        if down >= L: down = 0
        return coordinate_sequence(down, j)
    if neighbor_idx == 3:
        left = j - 1
        if left < 0: left = L - 1
        return coordinate_sequence(i, left)


def sequence_coordinate(seq_num):
    """
    :param: seq_num <= L*L - 1
    :return: coordinate tuple
    """
    col = seq_num % L
    row = (seq_num - col) // L
    return row, col


def coordinate_sequence(x, y):
    return x * L + y


#######################  Cluster  #############################
def cluster_update(Temperature):
    """
    This routine applies Wolff cluster update to achieve a configuration (u) trans.
    """
    ##  Start point  ##
    start = ran.randint(0, L * L - 1)
    cluster = []  # Store sequence number of cluster sites
    pocket = []
    cluster.append(start)
    pocket.append(start)

    ##  Cluster grow  ##
    beta = 1 / k_B / Temperature
    # print 'beta =', beta
    while len(pocket) > 0:
        k = ran.choice(pocket)
        for neighbor in range(4):
            l = neighbor_loc(seq_num=k, neighbor_idx=neighbor)
            x_l, y_l = sequence_coordinate(l)
            x_k, y_k = sequence_coordinate(k)
            if (l not in cluster) and (u[x_l][y_l] == u[x_k][y_k]):
                if ran.random() < (1 - np.exp(-2*beta*J_1)):
                    pocket.append(l)
                    cluster.append(l)
        pocket.remove(k)

    ##  Cluster flip according to new acceptance rate ##
    for i in range(L):
        for j in range(L):
            u_propose[i][j] = u[i][j]
    for k in cluster:
        x, y = sequence_coordinate(k)
        u_propose[x][y] = -u_propose[x][y]

    ising_tmp, E_A = config_energy_original(u)
    E_A_eff = config_energy_effective(u)
    ising_tmp, E_B = config_energy_original(u_propose)
    E_B_eff = config_energy_effective(u_propose)

    if ran.random() < np.exp(-beta * ((E_B - E_B_eff) - (E_A - E_A_eff))):
        for i in range(L):
            for j in range(L):
                u[i][j] = u_propose[i][j]
################  Measurement  ###################

def measure(Temperature):
    """
    :return: energy expectation value and variance of energy and magnetization
    """
    ##  Start measuring at low temperature  ##
    energy = []
    magnetization = []
    for sample in range(10):  # Sample 10 times
        cluster_update(Temperature)
        tmp, energy_tmp = config_energy_original(u)
        mag_tmp = config_magnetization(u)

        energy.append(energy_tmp)
        magnetization.append(mag_tmp)

    energy_av = av(energy)
    mag_av= av(magnetization)
    # sd = np.sqrt(var)
    return energy_av, mag_av

def av_and_var(input_array):
    """
    :param input_array: In put a list
    :return: Average and Variance as a tuple
    """
    array = np.array(input_array)
    average = float(array.sum()) / len(array)
    array2 = array * array
    array2sum = float(array2.sum())
    variance = array2sum / len(array) - average ** 2
    return average, variance

def av(input_array):
    """
    :param input_array: In put a list
    :return: Average value
    """
    array = np.array(input_array)
    average = float(array.sum()) / len(array)
    return average



################## MAIN #######################
k_B = 1.0  # Boltzmann constant
T_start = 1.0  # Absolute temperature
T_finish = 15.0  # From start temperature down to finish temperature
dT = 0.1  # Temperature step

group = 30  # Number of measurements carried out under each temperature
interval = 2000  # Interval between groups of measurements



def main():
    f_energy = open('energy&mag.dat', 'w+')
    config_init('Low temperature')

    for iT in range(int((- T_start + T_finish)//dT) + 1):
        T = T_start +iT * dT  # Annealing from T_start
        print T
        ##  Warm up after temperature changes ##
        warmup = 19999  # Need to check -- autocorrelation time

        for step in range(warmup):
            cluster_update(T)


        energy_tmp = []
        mag_tmp = []
        for group_measure in range(group):

            for i in range(interval):
                cluster_update(T)

            energy_av, mag_av = measure(T)
            energy_tmp.append(energy_av)
            mag_tmp.append(mag_av)

        E_result_mean, E_result_var = av_and_var(energy_tmp)
        M_result_mean, M_result_var = av_and_var(mag_tmp)
        f_energy.write('T = %6.3f, E = %7.4f, E_var = %7.4f, M = %7.4f, M_var = %7.4f\n' % (T, E_result_mean,
                                                                                            E_result_var,
                                                                                            M_result_mean,
                                                                                            M_result_var))

    f_energy.close()



t0 = time.clock()
t1 = time.time()

main()

print time.clock() - t0, 'CPU time'
print time.time() - t1, 'Wall time'
#################  TEST area  ######################

def test():
    config_init('High temperature')
    config_print()
    print 'Init', config_energy_original(u)
    print config_magnetization(u)
 #   cluster_update(2)
   # print cluster
    config_print()
  #  print 'Fin', config_energy(u)

# test()


