# coding = utf-8

import matplotlib.pyplot as plt
f = open('energy&mag.dat','r')
T = []
E = []
while True:
    txt = f.readline()
    # print txt
    if txt == '':
        break
    temperature = txt[4:9]
    energy = txt[16:23]
    T.append(float(temperature))
    E.append(float(energy))

f.close()

x0 = []
y = []
for i in range(55):
    x0.append(2.26918)
    y.append(i*0.05 -2.5)

x1 = []
for i in range(55):
    x1.append(2.65)

plt.ylim(-2.5,0)
plt.xlim(0,10)
plt.scatter(T, E, s=5)
plt.plot(x0,y,'--')
plt.plot(x1,y,'-')
# plt.savefig('E_T.png')
plt.show()


